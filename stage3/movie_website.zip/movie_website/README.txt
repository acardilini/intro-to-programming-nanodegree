README

Required:
Python2.7 installation
Access to the internet

Included:
media.py - specifies the class movie
fresh_tomatoes - writes HTML file taking in instances of class
entertainment_centre.py - constructs instances of class movie, calls fresh tomatoes and creates html page
best_speech_image.png - cropped image for best_speech poster_image
the README

Class Movie
----------------
Defines five instance variables including:
title = movie_title
storyline = movie_storyline
poster_image_url = poster_image
trailer_youtube_url = trailer_youtube
duration = movie_duration

Create Fresh Tomatoes HTML
----------------
To create the Fresh Tomatoes HTML page run the entertainment_centre.py source file using Python2.7.

E.g. in Terminal:
  $ python2 entertainment_centre.py

Do this from within the movie_website directory, or include the file location when running.

NOTE: All files must be within the same folder for the program to function as intended.
